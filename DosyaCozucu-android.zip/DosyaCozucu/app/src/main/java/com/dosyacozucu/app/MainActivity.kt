package com.dosyacozucu.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/**
 * Format: dosya UTF-8 yazı, her harfin kod numarası bir anahtarla (genelde 0x81) XOR'lanmış.
 * Dosya başında şifrelenmemiş BOM (EF BB BF) olabilir.
 */
class MainActivity : Activity() {

    private lateinit var info: TextView
    private lateinit var edit: EditText
    private lateinit var keyBox: EditText
    private lateinit var encSwitch: Switch

    private var srcUri: Uri? = null
    private var hadBom = false
    private var fileName = "kayit.pc"
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    // ---------- Arayüz ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        b.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        return b
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(12), dp(12), dp(12), dp(12))
        root.setBackgroundColor(Color.parseColor("#12151C"))

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(button("Aç") { openPicker() })
        row1.addView(button("Kaydet") { saveInPlace() })
        row1.addView(button("Yeni dosya") { saveAs() })
        root.addView(row1)

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.gravity = Gravity.CENTER_VERTICAL

        val keyLabel = TextView(this)
        keyLabel.text = "Anahtar (hex): "
        keyLabel.setTextColor(Color.parseColor("#9AA3B2"))
        row2.addView(keyLabel)

        keyBox = EditText(this)
        keyBox.setText("81")
        keyBox.setTextColor(Color.WHITE)
        keyBox.inputType = InputType.TYPE_CLASS_TEXT
        keyBox.layoutParams = LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT)
        row2.addView(keyBox)

        encSwitch = Switch(this)
        encSwitch.text = "  Şifre açık"
        encSwitch.setTextColor(Color.WHITE)
        encSwitch.isChecked = true
        encSwitch.setOnCheckedChangeListener { _, on ->
            encSwitch.text = if (on) "  Şifre açık" else "  Şifre kapalı"
        }
        val sp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        sp.leftMargin = dp(12)
        encSwitch.layoutParams = sp
        row2.addView(encSwitch)
        root.addView(row2)

        info = TextView(this)
        info.text = "\"Aç\" düğmesine bas ya da dosya yöneticisinden \"şununla aç\" ile seç."
        info.setTextColor(Color.parseColor("#9AA3B2"))
        info.setPadding(0, dp(8), 0, dp(8))
        root.addView(info)

        edit = EditText(this)
        edit.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        edit.typeface = Typeface.MONOSPACE
        edit.textSize = 12f
        edit.gravity = Gravity.TOP
        edit.setTextColor(Color.parseColor("#E8EBF2"))
        edit.setBackgroundColor(Color.parseColor("#222836"))
        edit.setPadding(dp(8), dp(8), dp(8), dp(8))
        edit.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        )
        root.addView(edit)

        setContentView(root)
    }

    // ---------- Dosya açma ----------

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> streamUri(i)
            else -> null
        }
        if (uri != null) load(uri)
    }

    @Suppress("DEPRECATION")
    private fun streamUri(i: Intent): Uri? {
        return if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
    }

    @Suppress("DEPRECATION")
    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        startActivityForResult(i, REQ_OPEN)
    }

    private fun queryName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun load(uri: Uri) {
        if (busy) return
        busy = true
        info.text = "Açılıyor..."
        Thread {
            try {
                val stream = contentResolver.openInputStream(uri)
                    ?: throw java.io.IOException("Dosya açılamadı")
                val raw = stream.use { it.readBytes() }
                val name = queryName(uri) ?: uri.lastPathSegment ?: "kayit.pc"
                val bom = raw.size >= 3 &&
                    raw[0] == 0xEF.toByte() && raw[1] == 0xBB.toByte() && raw[2] == 0xBF.toByte()
                val off = if (bom) 3 else 0
                val text = String(raw, off, raw.size - off, Charsets.UTF_8)
                val key = findKey(text)
                val shown = if (key != null) xorText(text, key) else text
                runOnUiThread {
                    srcUri = uri
                    fileName = name
                    hadBom = bom
                    edit.setText(shown)
                    keyBox.setText(String.format("%02x", key ?: 0x81))
                    encSwitch.isChecked = key != null
                    val keyInfo = if (key != null) {
                        "anahtar 0x" + String.format("%02x", key) + " bulundu"
                    } else {
                        "şifre bulunamadı, düz metin gösteriliyor"
                    }
                    info.text = name + " | " + raw.size + " bayt | " + keyInfo +
                        (if (bom) " | BOM var" else "")
                    busy = false
                }
            } catch (e: Exception) {
                runOnUiThread {
                    info.text = "Hata: " + e.message
                    busy = false
                }
            }
        }.start()
    }

    // ---------- Çözme / şifreleme ----------

    private fun isPrint(x: Int): Boolean =
        (x in 32..126) || x == 9 || x == 10 || x == 13

    /** Tüm dosyadan örnek alıp en okunur çıkan anahtarı bulur. Bulamazsa null. */
    private fun findKey(t: String): Int? {
        if (t.length < 8) return null
        val step = maxOf(1, t.length / 4096)
        val sample = ArrayList<Int>()
        var i = 0
        while (i < t.length) {
            sample.add(t[i].code)
            i += step
        }
        var bestK = 0
        var bestS = -1.0
        var bestR = 0.0
        val first = t[0].code
        for (k in 0..255) {
            var c = 0
            for (x in sample) if (isPrint(x xor k)) c++
            val r = c.toDouble() / sample.size
            val d = first xor k
            val bonus = if (d == 0x7B || d == 0x5B) 0.02 else 0.0
            if (r + bonus > bestS) {
                bestS = r + bonus
                bestK = k
                bestR = r
            }
        }
        return if (bestK == 0 || bestR < 0.9) null else bestK
    }

    private fun xorText(s: String, k: Int): String {
        val sb = StringBuilder(s.length)
        for (c in s) sb.append((c.code xor k).toChar())
        return sb.toString()
    }

    private fun currentBytes(): ByteArray {
        var s = edit.text.toString()
        if (encSwitch.isChecked) {
            val k = keyBox.text.toString().trim().removePrefix("0x").toIntOrNull(16)
                ?: throw IllegalArgumentException("Anahtar hex olmalı (örn. 81)")
            if (k !in 0..255) throw IllegalArgumentException("Anahtar 00-ff arası olmalı")
            s = xorText(s, k)
        }
        val body = s.toByteArray(Charsets.UTF_8)
        return if (hadBom) {
            byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + body
        } else {
            body
        }
    }

    // ---------- Kaydetme ----------

    private fun saveInPlace() {
        val uri = srcUri
        if (uri == null) {
            saveAs()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Üstüne yaz")
            .setMessage(fileName + " dosyasının üstüne yazılsın mı? Yedek aldığından emin ol.")
            .setPositiveButton("Yaz") { _, _ -> writeTo(uri, true) }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    @Suppress("DEPRECATION")
    private fun saveAs() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/octet-stream"
        i.putExtra(Intent.EXTRA_TITLE, fileName)
        startActivityForResult(i, REQ_SAVE)
    }

    private fun writeTo(uri: Uri, offerSaveAs: Boolean) {
        try {
            val data = currentBytes()
            val os = contentResolver.openOutputStream(uri, "wt")
                ?: throw java.io.IOException("Dosyaya yazılamadı")
            os.use { it.write(data) }
            info.text = "Kaydedildi: " + data.size + " bayt"
        } catch (e: Exception) {
            info.text = "Hata: " + e.message
            if (offerSaveAs && (e is SecurityException || e is java.io.IOException)) {
                info.text = "Üstüne yazılamadı (" + e.message + "). \"Yeni dosya\" ile kaydet."
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == REQ_OPEN) load(uri) else if (requestCode == REQ_SAVE) writeTo(uri, false)
    }

    companion object {
        private const val REQ_OPEN = 1
        private const val REQ_SAVE = 2
    }
}
