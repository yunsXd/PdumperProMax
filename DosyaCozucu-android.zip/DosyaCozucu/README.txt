Dosya Çözücü (Android)

Derleme (Android Studio):
  Klasörü aç -> Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk

Derleme (telefondan, GitHub ile):
  1) github.com'da yeni bir depo aç.
  2) Bu klasördeki TÜM dosyaları (.github klasörü dahil) depoya yükle.
  3) Actions sekmesi > "APK derle" > Run workflow.
  4) Bitince "DosyaCozucu-apk" çıktısını indir, zip içindeki app-debug.apk'yı kur.

Kullanım: dosya yöneticisinde dosyaya bas > "Dosya Çözücü" ile aç. Düzenle, Kaydet.
